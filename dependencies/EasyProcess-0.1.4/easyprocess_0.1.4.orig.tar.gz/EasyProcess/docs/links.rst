.. _scons: http://www.scons.org
.. _sphinx: http://sphinx.pocoo.org
.. _github: https://github.com/
.. _paver: http://paver.github.com/paver/ 
.. _setuptools: http://peak.telecommunity.com/DevCenter/EasyInstall
.. _pip: http://pip.openplans.org/
.. _nose: http://somethingaboutorange.com/mrl/projects/nose/1.0.0/
.. _ghp-import: https://github.com/davisp/ghp-import 
.. _pyflakes: http://pypi.python.org/pypi/pyflakes
.. _pychecker: http://pychecker.sourceforge.net/
.. _pypi: http://pypi.python.org/pypi
.. _`paved fork`: https://github.com/ponty/paved   
.. _sphinx-contrib: https://bitbucket.org/birkenfeld/sphinx-contrib/    
.. _sphinxcontrib-programscreenshot: https://github.com/ponty/sphinxcontrib-programscreenshot    
.. _sphinxcontrib-programoutput: http://packages.python.org/sphinxcontrib-programoutput/
.. _sphinxcontrib-paverutils: http://pypi.python.org/pypi/sphinxcontrib-paverutils


