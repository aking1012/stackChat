**entrypoint2**

:Date: |today|
:PDF: `entrypoint2.pdf <entrypoint2.pdf>`_

Contents:

.. toctree::
    :maxdepth: 2

    readme
    entrypoint_readme
    usage
    api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

