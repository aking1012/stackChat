API
===

.. automodule:: entrypoint2
    :members: entrypoint, UsageError
