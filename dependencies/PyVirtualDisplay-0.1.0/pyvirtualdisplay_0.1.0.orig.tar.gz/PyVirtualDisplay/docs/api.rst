API
===

.. autoclass:: pyvirtualdisplay.Display
    :members: start, stop

.. autoclass:: pyvirtualdisplay.smartdisplay.SmartDisplay
    :members:
    :undoc-members:







