from display import Display
import logging

__version__ = '0.1.0'

log = logging.getLogger(__name__)
log.debug('version=' + __version__)
